library(testthat)
library(FREEtree)

test_check("FREEtree")
